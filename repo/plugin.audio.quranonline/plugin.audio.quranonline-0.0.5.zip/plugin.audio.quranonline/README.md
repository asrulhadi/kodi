# plugin.audio.quranonline
Music addons to stream Holy Quran. All audio from https://quranicaudio.com/

TODO:
* Add setting for cache time (in hour)
* Add more source of audio

